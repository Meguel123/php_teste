
<div style= "">
<?php



$idade = $_GET["idade"];
$nome = $_GET["nome"];
$altura = $_GET["altura"];
$sexo = $_GET["sexo"];



echo "nome ". $nome;
echo "<br>";
echo "altura ". $altura;
echo "<br>";
echo "idade ". $idade;
echo "<br>";
echo "sexo ". $sexo;
echo "<br>";


?>
</div>